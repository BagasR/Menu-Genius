# Menu-Genius

Selamat datang di Genius. Aplikasi ini akan membantu anda dalam pencarian restoran berdasarkan lokasi, rating, jenis tempat dan rentang harga nya. Solusi ini dapat dengan mudah menemukan makanan dan restoran sesuai dengan pilihan Anda.
Ingin cari tahu nama restoran anda? coba cek dibawah ya.